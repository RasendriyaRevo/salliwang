<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <?php echo $__env->yieldContent('head'); ?>
        <link href="css/bootstrap.min.css" rel="stylesheet" >
        <link href="css/styles.css" rel="stylesheet" >
    <head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
    </body>
    <footer>
        <?php echo $__env->yieldContent('foot'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/navshrink.js"></script>
    </footer>
<html><?php /**PATH D:\FILE DYEVA\PROJECT\salliwang\resources\views/header.blade.php ENDPATH**/ ?>